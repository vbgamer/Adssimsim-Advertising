


import React, { useState, useEffect } from 'react';
import { Campaign, User } from '../../types';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import CreateCampaignForm from './CreateCampaignForm';
import CampaignList from './CampaignList';
import Card from '../ui/Card';
import { supabase } from '../../supabaseClient';
import EditProfileModal from './EditProfileModal';
import AudienceAnalytics from './AudienceAnalytics';

interface AdvertiserDashboardProps {
  campaigns: Campaign[];
  onCampaignAdded: () => void;
  user: User;
  onLogout: () => void;
  onUserUpdated: (updatedData: Partial<User>) => void;
}

const AdvertiserDashboard: React.FC<AdvertiserDashboardProps> = ({ campaigns: initialCampaigns, onCampaignAdded, user, onLogout, onUserUpdated }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  // FIX: Manage campaigns in local state to allow for optimistic UI updates.
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns);

  useEffect(() => {
    setCampaigns(initialCampaigns);
  }, [initialCampaigns]);


  const visibleCampaigns = campaigns.filter(c => c.status !== 'Uploading' && c.status !== 'Upload Failed');
  const totalRewardedPoints = visibleCampaigns.reduce((sum, c) => sum + (c.rewardedPoints || 0), 0);
  const totalImpressions = visibleCampaigns.reduce((sum, c) => sum + c.impressions, 0);
  
  const handleCampaignSubmit = async (
    newCampaignData: Omit<Campaign, 'id' | 'impressions' | 'clicks' | 'status' | 'advertiser_id'>,
    creativeFile: File
  ) => {
    setIsModalOpen(false); // Close modal immediately for a responsive feel

    const tempId = `temp-${Date.now()}`;
    const tempCampaign: Campaign = {
      ...newCampaignData,
      id: tempId,
      advertiser_id: user.id,
      impressions: 0,
      clicks: 0,
      status: 'Uploading',
      adCreativeUrl: URL.createObjectURL(creativeFile), // Temporary local URL for preview
      rewardedPoints: 0,
    };

    // FIX: Use the local state setter `setCampaigns` to add the temporary campaign for an optimistic update.
    setCampaigns(prev => [tempCampaign, ...prev]);

    try {
      // 1. Upload creative
      const filePath = `public/${Date.now()}-${creativeFile.name.replace(/\s/g, '_')}`;
      const { error: uploadError } = await supabase.storage
        .from('campaign_creatives')
        .upload(filePath, creativeFile);
      
      if (uploadError) throw uploadError;

      // 2. Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('campaign_creatives')
        .getPublicUrl(filePath);

      // 3. Insert campaign into database
      const { error } = await supabase
        .from('campaigns')
        .insert({
          name: newCampaignData.name,
          budget: newCampaignData.budget,
          reward: newCampaignData.reward,
          ad_creative_url: publicUrl,
          target_audience: newCampaignData.targetAudience,
          campaign_goal: newCampaignData.campaignGoal,
          region: newCampaignData.region,
          gender: newCampaignData.gender,
          cta_text: newCampaignData.ctaText,
          landing_page_url: newCampaignData.landingPageUrl,
          type: newCampaignData.type,
          category: newCampaignData.category,
          company: newCampaignData.company,
          duration: newCampaignData.duration,
          advertiser_id: user.id,
          status: 'Pending', // Set status to Pending for review
        });

      if (error) throw error;
      
      // 4. Refresh campaign list from DB
      onCampaignAdded();
    } catch (error: any) {
        const errorMessage = error.message || 'Upload failed. Please try again.';
        console.error("Error creating campaign background task failed:", errorMessage, error);
        // Update the temporary campaign to show failure status
        // FIX: Use the local state setter `setCampaigns` to update the campaign status on failure.
        setCampaigns(prev => prev.map(c => c.id === tempId ? { ...c, status: 'Upload Failed', uploadError: errorMessage } : c));
    }
  }

  const handleProfileUpdate = async (updatedData: { username: string; logoFile?: File; bannerFile?: File }) => {
    try {
        const updates: { username: string; logo_url?: string; banner_url?: string } = {
            username: updatedData.username,
        };

        const uploadFile = async (file: File, folder: string) => {
            const filePath = `public/profiles/${user.id}/${folder}/${Date.now()}-${file.name.replace(/\s/g, '_')}`;
            const { error: uploadError } = await supabase.storage
                .from('campaign_creatives')
                .upload(filePath, file);
            if (uploadError) throw uploadError;
            const { data: { publicUrl } } = supabase.storage
                .from('campaign_creatives')
                .getPublicUrl(filePath);
            return publicUrl;
        };
        
        if (updatedData.logoFile) {
            updates.logo_url = await uploadFile(updatedData.logoFile, 'logos');
        }

        if (updatedData.bannerFile) {
            updates.banner_url = await uploadFile(updatedData.bannerFile, 'banners');
        }

        const { data, error } = await supabase
            .from('profiles')
            .update(updates)
            .eq('id', user.id)
            .select()
            .single();

        if (error) throw error;
        
        if (data) {
            onUserUpdated({
                username: data.username,
                logoUrl: data.logo_url || undefined,
                bannerUrl: data.banner_url || undefined,
            });
        }

        setIsEditProfileModalOpen(false);
    } catch (error: any) {
        console.error('Error updating profile:', error);
        throw new Error(error.message || 'Failed to update profile. Please try again.');
    }
  };

  return (
    <div className="bg-slate-900 min-h-screen text-white">
      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-sm sticky top-0 z-40 border-b border-slate-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
           <span className="text-xl font-bold text-white">Advertiser Hub</span>
           <div className="flex items-center gap-4">
             <Button onClick={() => setIsModalOpen(true)} variant="primary">Create Campaign</Button>
             <Button onClick={onLogout} variant="secondary">Sign Out</Button>
           </div>
        </div>
      </header>

      {/* Profile Section */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mt-8">
          <div className="h-48 md:h-64 bg-slate-800 rounded-2xl overflow-hidden">
            {user.bannerUrl ? <img src={user.bannerUrl} alt="Company banner" className="w-full h-full object-cover" /> : <div className="w-full h-full bg-slate-800"></div>}
          </div>
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 sm:-mt-20">
            <div className="flex items-end space-x-5">
              <div className="h-32 w-32 sm:h-40 sm:w-40 rounded-full ring-4 ring-slate-900 overflow-hidden bg-slate-700">
                {user.logoUrl && <img src={user.logoUrl} alt="Company logo" className="h-full w-full object-cover" />}
              </div>
              <div className="pb-4 sm:pb-6 flex-grow flex items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold text-white">{user.username}</h1>
                  <p className="text-sm text-slate-400">{user.subscribers?.toLocaleString() ?? 0} Subscribers</p>
                </div>
                <Button variant="secondary" onClick={() => setIsEditProfileModalOpen(true)}>Edit Profile</Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="mt-12 space-y-12">
            {/* Analytics Section */}
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">Key Metrics</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="p-6">
                  <h3 className="text-slate-400 text-sm font-medium">Credit Balance</h3>
                  <p className="text-3xl font-semibold text-white">{(user.creditBalance ?? 0).toLocaleString()} PTS</p>
                </Card>
                <Card className="p-6">
                  <h3 className="text-slate-400 text-sm font-medium">Points Rewarded</h3>
                  <p className="text-3xl font-semibold text-white mt-1">{totalRewardedPoints.toLocaleString()}</p>
                </Card>
                <Card className="p-6">
                  <h3 className="text-slate-400 text-sm font-medium">Reach </h3>
                  <p className="text-3xl font-semibold text-white mt-1">{totalImpressions.toLocaleString()}</p>
                </Card>
              </div>
            </div>

            <div>
                <h2 className="text-2xl font-bold text-white mb-4">Platform Audience Demographics</h2>
                <AudienceAnalytics />
            </div>

            {/* Manage Campaigns Section */}
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">Manage Your Campaigns</h2>
              <CampaignList campaigns={campaigns} />
            </div>
        </div>
      </div>
      
      <div className="pb-16"></div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create New Campaign">
        <CreateCampaignForm 
          onCampaignSubmit={handleCampaignSubmit}
          onClose={() => setIsModalOpen(false)}
          company={{
            name: user.username,
            logoUrl: user.logoUrl || `https://picsum.photos/seed/${user.username}logo/100`,
            subscriberCount: user.subscribers || 0,
          }}
        />
      </Modal>

      <EditProfileModal
        isOpen={isEditProfileModalOpen}
        onClose={() => setIsEditProfileModalOpen(false)}
        user={user}
        onProfileUpdate={handleProfileUpdate}
      />
    </div>
  );
};

export default AdvertiserDashboard;