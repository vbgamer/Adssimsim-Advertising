import React, { useState, useCallback } from 'react';
import { Campaign, WatchedAd, User } from '../../types';
import AdFeed from './AdFeed';
import LitFeed from './LitFeed';
import AdPlayer from './AdPlayer';
import ViewerHeader from './ViewerHeader';
import BottomNavBar, { ViewerTab } from './BottomNavBar';
import ProfilePage from './ProfilePage';

interface ViewerDashboardProps {
  campaigns: Campaign[];
  user: User;
  onLogout: () => void;
  onRewardClaimed: (campaign: Campaign, reward: number) => void;
}

const ViewerDashboard: React.FC<ViewerDashboardProps> = ({ campaigns, user, onLogout, onRewardClaimed }) => {
  const [activeAd, setActiveAd] = useState<Campaign | null>(null);
  const [watchedHistory, setWatchedHistory] = useState<WatchedAd[]>([]);
  const [activeTab, setActiveTab] = useState<ViewerTab>('Lit');
  const [searchQuery, setSearchQuery] = useState('');

  const handleWatchAd = useCallback((ad: Campaign) => {
    setActiveAd(ad);
  }, []);

  const handleClaimReward = useCallback((ad: Campaign, reward: number) => {
    onRewardClaimed(ad, reward);
    setWatchedHistory(prevHistory => [{ ...ad, watchedOn: new Date() }, ...prevHistory]);
    // The player is no longer closed automatically upon reward claim.
    // This allows the user to click the call-to-action button after reacting.
    // The user can close the player by clicking the backdrop.
  }, [onRewardClaimed]);

  const handleClosePlayer = useCallback(() => {
    setActiveAd(null);
  }, []);
  
  const searchedCampaigns = campaigns.filter(campaign => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) return true; // Show all if search is empty
    return (
      campaign.name.toLowerCase().includes(query) ||
      (campaign.category && campaign.category.toLowerCase().includes(query)) ||
      campaign.company.name.toLowerCase().includes(query)
    );
  });

  const renderContent = () => {
    switch(activeTab) {
      case 'Explore':
        return <AdFeed campaigns={searchedCampaigns} onWatchAd={handleWatchAd} />;
      case 'Lit':
        return <LitFeed campaigns={searchedCampaigns.filter(c => c.type === 'Video')} onWatchAd={handleWatchAd} />;
      case 'You':
        return <ProfilePage user={user} onLogout={onLogout} watchedHistory={watchedHistory} rewardPoints={user.rewardPoints || 0} />;
      default:
        return null;
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <ViewerHeader searchQuery={searchQuery} onSearchChange={setSearchQuery} />
      
      <main className="flex-grow container mx-auto px-4 py-8 pb-24">
         {renderContent()}
      </main>
      
      <BottomNavBar activeTab={activeTab} onTabChange={setActiveTab} />

      {activeAd && (
        <AdPlayer 
          ad={activeAd} 
          onClaimReward={handleClaimReward} 
          onClose={handleClosePlayer} 
        />
      )}
    </div>
  );
};

export default ViewerDashboard;