import React, { useState, useEffect, useRef } from 'react';
import { Campaign } from '../../types';
import Button from '../ui/Button';

interface AdPlayerProps {
  ad: Campaign;
  onClaimReward: (ad: Campaign, reward: number) => void;
  onClose: () => void;
}

const AdPlayer: React.FC<AdPlayerProps> = ({ ad, onClaimReward, onClose }) => {
  const [reaction, setReaction] = useState<string | null>(null);
  const [isAdWatched, setIsAdWatched] = useState(false);
  const [isRewardClaimed, setIsRewardClaimed] = useState(false);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const isVideo = ad.adCreativeUrl.toLowerCase().endsWith('.mp4') || ad.adCreativeUrl.toLowerCase().endsWith('.webm');

  // Effect to handle progress and watched status.
  // Also resets state when the ad changes to ensure a fresh player.
  useEffect(() => {
    setIsAdWatched(false);
    setProgress(0);
    setReaction(null);
    setIsRewardClaimed(false);

    if (isVideo) {
      // For videos, watched status is handled by the onEnded event.
    } else {
      // For images, we use a timer based on the campaign duration.
      const durationMs = ad.duration * 1000;
      if (durationMs > 0) {
        const startTime = Date.now();
        let animationFrameId: number;

        const updateImageProgress = () => {
          const elapsedTime = Date.now() - startTime;
          const currentProgress = Math.min((elapsedTime / durationMs) * 100, 100);
          setProgress(currentProgress);

          if (elapsedTime < durationMs) {
            animationFrameId = requestAnimationFrame(updateImageProgress);
          } else {
            setIsAdWatched(true);
          }
        };
        animationFrameId = requestAnimationFrame(updateImageProgress);
        return () => cancelAnimationFrame(animationFrameId);
      } else {
        // If duration is 0 or not set for an image, consider it watched instantly.
        setIsAdWatched(true);
        setProgress(100);
      }
    }
  }, [ad.id, ad.duration, isVideo]);

  // Effect to automatically claim the reward once viewing is complete and feedback is given.
  useEffect(() => {
    if (isAdWatched && reaction && !isRewardClaimed) {
      onClaimReward(ad, ad.reward);
      setIsRewardClaimed(true);
    }
  }, [isAdWatched, reaction, isRewardClaimed, onClaimReward, ad]);

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const { currentTime, duration } = videoRef.current;
      if (duration > 0) {
        setProgress((currentTime / duration) * 100);
      }
    }
  };

  const handleVideoEnd = () => {
    setIsAdWatched(true);
    setProgress(100);
  };

  const handleCTAClick = () => {
    window.open(ad.landingPageUrl, '_blank', 'noopener,noreferrer');
    // Reward is now claimed automatically after rating. This button just opens the link.
  };

  const getButtonTitle = () => {
    if (!isAdWatched) return "Please watch the ad to the end";
    return ""; // No title needed when button is enabled.
  };
  
  const reactions = [
    { label: 'Impressed', emoji: '🔥' },
    { label: 'Relatable', emoji: '💯' },
    { label: 'Decent', emoji: '🙂' },
    { label: 'Boring', emoji: '🥱' },
    { label: 'Desperate', emoji: '🤡' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-md z-50 flex justify-center items-center p-4" onClick={onClose}>
      <div className="bg-slate-800/80 rounded-2xl shadow-2xl w-full max-w-4xl h-full max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
            <div className="flex items-center gap-3">
                <img src={ad.company.logoUrl} alt={ad.company.name} className="h-10 w-10 rounded-full bg-slate-700" />
                <div>
                    <p className="font-bold text-white">{ad.company.name}</p>
                    <p className="text-xs text-slate-400">{ad.company.subscriberCount.toLocaleString()} subscribers</p>
                </div>
            </div>
            <Button variant="secondary" size="sm">Show Interest</Button>
        </div>
        
        {/* Ad Content */}
        <div className="flex-grow bg-black flex items-center justify-center overflow-hidden relative">
             {isVideo ? (
                <video 
                    ref={videoRef}
                    src={ad.adCreativeUrl} 
                    autoPlay 
                    muted 
                    playsInline
                    className="w-full h-full object-contain"
                    onTimeUpdate={handleTimeUpdate}
                    onEnded={handleVideoEnd}
                >
                    Your browser does not support the video tag.
                </video>
             ) : (
                <img src={ad.adCreativeUrl} alt={ad.name} className="w-full h-full object-contain" />
             )}
            {/* Progress Bar */}
            <div className="absolute bottom-0 left-0 w-full h-1.5 bg-slate-600/50">
                <div 
                    className="h-full bg-primary-500 transition-all duration-150 ease-linear" 
                    style={{ width: `${progress}%` }}
                ></div>
            </div>
        </div>

        {/* Actions */}
        <div className="p-4 space-y-4 border-t border-slate-700">
            <div className="space-y-3">
                <p className="text-center text-sm font-semibold text-white">How was this ad?</p>
                <div className="flex flex-wrap items-center justify-center gap-2">
                    {reactions.map(({ label, emoji }) => (
                        <button
                            key={label}
                            onClick={() => setReaction(label)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all text-sm font-semibold ${
                                reaction === label
                                    ? 'bg-primary-600 text-white ring-2 ring-primary-400 scale-105 shadow-lg'
                                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                            }`}
                            aria-pressed={reaction === label}
                            disabled={isRewardClaimed}
                        >
                            <span>{emoji}</span>
                            {label}
                        </button>
                    ))}
                </div>
                 <div className="text-center text-xs pt-2 h-4">
                    {!isAdWatched && <p className="text-amber-400">Watch the ad completely to claim your reward.</p>}
                    {isAdWatched && !reaction && <p className="text-slate-400">Please react to claim your reward.</p>}
                    {isRewardClaimed && <p className="font-semibold text-emerald-400">Reward Claimed! Your history is updated.</p>}
                 </div>
            </div>
            
            <div className="flex items-center gap-3 pt-2">
                 {ad.discount && <Button variant="primary" className="w-full">{ad.discount}</Button>}
                 <Button 
                    onClick={handleCTAClick} 
                    className="w-full" 
                    variant="success"
                    disabled={!isAdWatched}
                    title={getButtonTitle()}
                 >
                    {ad.ctaText}
                 </Button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AdPlayer;