
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: any }
  | any[]

export interface Database {
  public: {
    Tables: {
      campaigns: {
        Row: {
          ad_creative_url: string
          advertiser_id: string
          budget: number
          campaign_goal: "Brand Awareness" | "Lead Generation" | "Sales"
          category: string
          clicks: number
          company: Json
          created_at: string
          cta_text: string
          discount: string | null
          duration: number
          gender: string
          id: string
          impressions: number
          landing_page_url: string
          name: string
          region: string
          reward: number
          rewarded_points: number | null
          status: "Active" | "Paused" | "Finished" | "Pending" | "Rejected"
          target_audience: string
          type: "Video" | "Shortz"
        }
        Insert: {
          ad_creative_url: string
          advertiser_id: string
          budget: number
          campaign_goal: "Brand Awareness" | "Lead Generation" | "Sales"
          category: string
          clicks?: number
          company: Json
          created_at?: string
          cta_text: string
          discount?: string | null
          duration: number
          gender: string
          id?: string
          impressions?: number
          landing_page_url: string
          name: string
          region: string
          reward: number
          rewarded_points?: number | null
          status?: "Active" | "Paused" | "Finished" | "Pending" | "Rejected"
          target_audience: string
          type: "Video" | "Shortz"
        }
        Update: {
          ad_creative_url?: string
          advertiser_id?: string
          budget?: number
          campaign_goal?: "Brand Awareness" | "Lead Generation" | "Sales"
          category?: string
          clicks?: number
          company?: Json
          created_at?: string
          cta_text?: string
          discount?: string | null
          duration?: number
          gender?: string
          id?: string
          impressions?: number
          landing_page_url?: string
          name?: string
          region?: string
          reward?: number
          rewarded_points?: number | null
          status?: "Active" | "Paused" | "Finished" | "Pending" | "Rejected"
          target_audience?: string
          type?: "Video" | "Shortz"
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_advertiser_id_fkey"
            columns: ["advertiser_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
      }
      profiles: {
        Row: {
          banner_url: string | null
          city: string | null
          country: string | null
          credit_balance: number | null
          email: string
          gender: string | null
          id: string
          logo_url: string | null
          reward_points: number | null
          role: "advertiser" | "viewer"
          state: string | null
          subscribers: number | null
          username: string
        }
        Insert: {
          banner_url?: string | null
          city?: string | null
          country?: string | null
          credit_balance?: number | null
          email: string
          gender?: string | null
          id: string
          logo_url?: string | null
          reward_points?: number | null
          role: "advertiser" | "viewer"
          state?: string | null
          subscribers?: number | null
          username: string
        }
        Update: {
          banner_url?: string | null
          city?: string | null
          country?: string | null
          credit_balance?: number | null
          email?: string
          gender?: string | null
          id?: string
          logo_url?: string | null
          reward_points?: number | null
          role?: "advertiser" | "viewer"
          state?: string | null
          subscribers?: number | null
          username?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}